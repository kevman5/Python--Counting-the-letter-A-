# -*- coding: utf-8 -*-
"""
Created on Tue Mar 23 20:14:44 2021

@author: kevmm
"""

word1 = input("Enter banana: ")
index = 0
count = 0
for letter in word1:
    if letter == 'a':
        count = count + 1
        print("The number of a's in banana =",count)
        
       
        
            
